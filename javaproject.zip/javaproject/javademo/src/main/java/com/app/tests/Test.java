package com.app.tests;

public class Test {

	public static void main(String[] args) {
		System.out.println("Java Concurrency");
	}

}
