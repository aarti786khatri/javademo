package com.app.dao;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;

public class dbConnection {
	public static Connection getConnection() throws ClassNotFoundException, SQLException{
		Connection connection = null;
		Class.forName("com.mysql.jdbc.=Driver");
		connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root");
		return connection;
	}
}
