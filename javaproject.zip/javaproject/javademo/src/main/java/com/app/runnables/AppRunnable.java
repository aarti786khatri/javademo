package com.app.runnables;

public class AppRunnable implements Runnable {

	public static void main(String[] args) {
		AppRunnable runnable = new AppRunnable();
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
